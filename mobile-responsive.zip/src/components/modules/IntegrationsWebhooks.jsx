import React, { useState, useEffect, useCallback, useMemo } from "react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";
import { INITIAL_DATA, METHODOLOGIES, SCENARIOS, STATUT_COLORS, PRIORITE_COLORS, PIE_COLORS, MODULES } from "../../data/constants";
import { Badge, ProgressBar, StatCard, Modal, Input, Select, Textarea, Btn, SectionHeader } from "../ui";

const IntegrationsWebhooks = ({ data, setData }) => {
  return (
    <div className="space-y-6">
      <SectionHeader title="Intégrations & Webhooks" subtitle="Connectez ProjetÉlite au reste de votre écosystème logiciel via API" action={<Btn size="md" className="bg-indigo-600">+ Nouveau Webhook</Btn>} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {[
          { name: "Slack", icon: "💬", desc: "Notification sur channel dédié", active: true },
          { name: "Microsoft Teams", icon: "👥", desc: "Alertes financières directes", active: true },
          { name: "Jira", icon: "🎫", desc: "Synchronisation bi-directionnelle", active: true },
          { name: "GitLab / GitHub", icon: "🐙", desc: "Lien entre commits et tâches", active: false },
          { name: "Salesforce", icon: "☁", desc: "Création auto de portail client", active: false },
        ].map(i => (
          <div key={i.name} className={`border rounded-xl p-5 flex items-start gap-4 transition-all hover:bg-slate-800 ${i.active ? "bg-slate-800/80 border-indigo-500/50" : "bg-slate-900/50 border-slate-700"}`}>
            <div className={`text-3xl ${i.active ? "" : "grayscale opacity-40"}`}>{i.icon}</div>
            <div className="flex-1">
              <h3 className="text-sm font-bold text-white">{i.name}</h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{i.desc}</p>
              <div className="mt-4">
                {i.active ? (
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded">✔ CONNECTÉ</span>
                ) : (
                  <Btn variant="ghost" size="sm" className="text-[10px] py-1">Connecter</Btn>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-700 flex justify-between items-center bg-slate-900/50">
          <h3 className="text-sm font-bold text-white">Endpoints Webhooks Configurés</h3>
          <span className="text-xs text-slate-400">{data.length} actifs</span>
        </div>
        <div className="overflow-x-auto -mx-1">
        <table className="w-full">
          <thead><tr className="border-b border-slate-700">
            {["Service / Nom", "URL Endpoint", "Événement Déclencheur", "Statut"].map(h => <th key={h} className="px-4 py-3 text-left text-xs font-bold text-slate-400 uppercase">{h}</th>)}
          </tr></thead>
          <tbody>
            {data.map(w => {
              const color = w.statut === "Connecté" ? "#10b981" : w.statut === "Erreur" ? "#ef4444" : "#f59e0b";
              return (
                <tr key={w.id} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                  <td className="px-4 py-3 text-sm font-bold text-white">{w.nom}</td>
                  <td className="px-4 py-3 text-xs text-indigo-300 font-mono truncate max-w-[200px]">{w.url}</td>
                  <td className="px-4 py-3 text-xs text-slate-300"><span className="bg-slate-700 px-2 py-1 rounded text-slate-300">{w.event}</span></td>
                  <td className="px-4 py-3"><Badge value={w.statut} map={{ "Connecté": "#10b981", "Erreur": "#ef4444", "En pause": "#f59e0b" }} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
</div>
      </div>
    </div>
  );
};

export default IntegrationsWebhooks;
